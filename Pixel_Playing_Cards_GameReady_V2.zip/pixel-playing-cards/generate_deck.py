#!/usr/bin/env python3
"""Deterministic original pixel-art playing cards; Python 3 + Pillow + NumPy.
Creates the complete 55-card deck in both 1x and 2x, validated atlases,
metadata, and an inspection preview. Regeneration is deterministic.
"""
from PIL import Image, ImageDraw, ImageFont
from collections import deque
from pathlib import Path
import json, zipfile, sys, math, os
import numpy as np

ROOT = Path(__file__).resolve().parent
W,H = 48,72
SW,SH=96,144
OUT2=(192,288)
ARTIST_VERSION='2.0'
C = {
 'ink':(37,31,38,255),'outline':(31,27,35,255), 'gold':(178,125,61,255),
 'gold_light':(236,197,110,255), 'ivory':(255,247,222,255),
 'ivory_shadow':(240,226,191,255),'ivory_white':(255,252,239,255),
 'red':(165,34,53,255),'black':(35,34,49,255),
 'burgundy':(89,25,49,255),'burgundy_deep':(63,19,42,255),
 'transparent':(0,0,0,0)
}
SUITS=[('hearts','H','red'),('diamonds','D','red'),('clubs','C','black'),('spades','S','black')]
RANKS=['A','2','3','4','5','6','7','8','9','10','J','Q','K']
# Connected, hand-pixeled 7x7 glyphs. Exactly one component per icon.
BITMAP={
 'H':[ '.XX.XX.', 'XXXXXXX', 'XXXXXXX', '.XXXXX.', '..XXX..', '...X...', '.......'],
 'D':[ '...X...', '..XXX..', '.XXXXX.', 'XXXXXXX', '.XXXXX.', '..XXX..', '...X...'],
 'C':[ '..XXX..', '.XXXXX.', 'XX.X.XX', 'XXXXXXX', 'XX.X.XX', '...X...', '..XXX..'],
 'S':[ '...X...', '..XXX..', '.XXXXX.', 'XXXXXXX', 'XX.X.XX', '...X...', '..XXX..'],
}
# Pure-pixel 3x5 font. Spacing always 1px, including the two-character "10".
FONT={
 'A':['010','101','111','101','101'], '2':['110','001','010','100','111'],
 '3':['110','001','011','001','110'], '4':['101','101','111','001','001'],
 '5':['111','100','110','001','110'], '6':['011','100','110','101','010'],
 '7':['111','001','010','010','010'], '8':['010','101','010','101','010'],
 '9':['010','101','011','001','110'], '1':['010','110','010','010','111'],
 '0':['111','101','101','101','111'], 'J':['001','001','001','101','010'],
 'Q':['010','101','101','111','011'], 'K':['101','110','100','110','101'],
 'O':['010','101','101','101','010'], 'E':['111','100','110','100','111'],
 'R':['110','101','110','101','101'], 'B':['110','101','110','101','110'],
 'L':['100','100','100','100','111'], 'C':['011','100','100','100','011'], 'U':['101','101','101','101','111'], 'D':['110','101','101','101','110'],
}

def draw_glyph(im, char, x, y, color, scale=1):
 d=ImageDraw.Draw(im)
 for row,line in enumerate(FONT[char]):
  for col,bit in enumerate(line):
   if bit=='1': d.rectangle((x+col*scale,y+row*scale,x+(col+1)*scale-1,y+(row+1)*scale-1), fill=color)

def glyph_width(s, scale=1): return ((len(s)*3)+(len(s)-1))*scale

def write_text(im,s,x,y,color,scale=1):
 for k,ch in enumerate(s): draw_glyph(im,ch,x+k*4*scale,y,color,scale)

def suit_icon(im,suit,cx,cy,color=None,scale=1):
 """Draw precisely one single-connected symbol centred on (cx,cy)."""
 color=color or C['red' if suit in ('H','D') else 'black']
 pat=BITMAP[suit]
 x0=cx-(7*scale)//2; y0=cy-(7*scale)//2
 d=ImageDraw.Draw(im)
 for yi,line in enumerate(pat):
  for xi,bit in enumerate(line):
   if bit=='X':
    d.rectangle((x0+xi*scale,y0+yi*scale,x0+(xi+1)*scale-1,y0+(yi+1)*scale-1),fill=color)

def card_template():
 im=Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(im)
 # Transparent outside a stepped/pixel-rounded silhouette.
 d.polygon([(4,1),(43,1),(46,4),(46,67),(43,70),(4,70),(1,67),(1,4)], fill=C['outline'])
 d.polygon([(5,2),(42,2),(45,5),(45,66),(42,69),(5,69),(2,66),(2,5)],fill=C['gold'])
 d.polygon([(5,3),(42,3),(44,5),(44,66),(42,68),(5,68),(3,66),(3,5)],fill=C['ivory_shadow'])
 d.rectangle((4,5,43,65), fill=C['ivory'])
 d.rectangle((4,5,43,7),fill=C['ivory_white'])
 d.line([(5,4),(42,4)],fill=C['ivory_white'])
 d.line([(5,67),(42,67)],fill=C['gold_light'])
 # Four unobtrusive corner ornaments in gold, not suit-shaped.
 for x in [5,42]:
  for y in [8,63]:
   d.point((x,y),fill=C['gold_light'])
 return im

def corner_indices(im,rank,suit):
 badge=Image.new('RGBA',(W,H),(0,0,0,0))
 color=C['red' if suit in ('H','D') else 'black']
 # Rank 10 uses two 3x5 digit glyphs, with true '10'.
 x=5 if rank=='10' else 7
 write_text(badge,rank,x,7,color)
 suit_icon(badge,suit,7,18,color,scale=1)
 im.alpha_composite(badge)
 im.alpha_composite(badge.rotate(180))

# A classic countable layout; positions are the ONLY source of center pips.
PIP_POINTS={
 'A':[(24,36)],
 '2':[(24,23),(24,50)],
 '3':[(24,22),(24,36),(24,50)],
 '4':[(16,23),(32,23),(16,49),(32,49)],
 '5':[(16,23),(32,23),(24,36),(16,49),(32,49)],
 '6':[(16,23),(32,23),(16,36),(32,36),(16,49),(32,49)],
 '7':[(16,23),(32,23),(24,29),(16,36),(32,36),(16,49),(32,49)],
 '8':[(16,23),(32,23),(24,28),(16,36),(32,36),(24,44),(16,49),(32,49)],
 '9':[(16,21),(32,21),(16,31),(32,31),(24,36),(16,41),(32,41),(16,51),(32,51)],
 '10':[(16,21),(32,21),(24,27),(16,31),(32,31),(16,41),(32,41),(24,45),(16,51),(32,51)]
}

def numeric_card(rank,suit):
 im=card_template(); color=C['red' if suit in ('H','D') else 'black']
 for cx,cy in PIP_POINTS[rank]:
  suit_icon(im,suit,cx,cy,color,scale=2 if rank=='A' else 1)
 corner_indices(im,rank,suit)
 return im

# Per-suit illustrated palettes and details, consciously developed for low-res readability.
ROYAL={
 'H':{'coat':(147,37,59,255),'shade':(103,28,52,255),'trim':(244,193,89,255),
      'back':(250,225,204,255),'hair':(104,52,44,255),'skin':(239,184,137,255),
      'skinshade':(201,126,104,255),'accent':(192,40,66,255),'gem':(213,53,70,255)},
 'D':{'coat':(189,85,49,255),'shade':(126,50,40,255),'trim':(250,199,99,255),
      'back':(249,232,203,255),'hair':(82,52,32,255),'skin':(231,172,117,255),
      'skinshade':(188,109,79,255),'accent':(224,117,47,255),'gem':(206,62,42,255)},
 'C':{'coat':(40,82,85,255),'shade':(27,53,65,255),'trim':(218,174,95,255),
      'back':(215,231,218,255),'hair':(54,48,63,255),'skin':(213,154,119,255),
      'skinshade':(168,97,86,255),'accent':(53,105,90,255),'gem':(80,176,116,255)},
 'S':{'coat':(63,64,113,255),'shade':(35,38,79,255),'trim':(210,210,206,255),
      'back':(220,218,235,255),'hair':(63,56,70,255),'skin':(218,170,142,255),
      'skinshade':(168,112,107,255),'accent':(93,91,155,255),'gem':(113,135,209,255)}
}

def face_card(rank,suit):
 im=card_template(); d=ImageDraw.Draw(im); p=ROYAL[suit]; dark=C['outline']
 # Architectural frame in central illustration region with gold studs.
 d.rectangle((12,21,35,53), fill=dark)
 d.rectangle((13,22,34,52), fill=p['trim'])
 d.rectangle((14,23,33,51), fill=p['back'])
 d.rectangle((15,23,32,26),fill=C['ivory_white'])
 # Colored faceted stained-glass panels, never ambiguous as suit icons.
 for y in range(27,50,7):
  d.line([(14,y),(17,y-3)],fill=C['ivory_shadow'])
  d.line([(33,y),(30,y-3)],fill=C['ivory_shadow'])
 # Cape: shoulders/headpiece forming 12 unique portraits.
 d.polygon([(15,50),(16,46),(19,43),(22,42),(27,42),(31,44),(33,49),(33,51),(15,51)], fill=dark)
 d.polygon([(16,50),(17,46),(21,43),(27,43),(31,46),(32,51),(16,51)],fill=p['coat'])
 d.polygon([(16,50),(18,46),(20,45),(21,51)],fill=p['shade'])
 d.polygon([(32,50),(30,46),(28,45),(27,51)],fill=p['shade'])
 d.polygon([(21,43),(24,46),(27,43),(28,45),(24,51),(20,45)],fill=p['trim'])
 d.polygon([(22,45),(24,47),(26,45),(25,51),(23,51)],fill=C['ivory_white'])
 # Coloured diagonal insignia varies by suit.
 if suit in ('H','S'):
  d.line([(17,46),(22,51)],fill=p['trim'],width=1)
 else:
  d.line([(31,46),(26,51)],fill=p['trim'],width=1)
 d.point((24,48),fill=p['gem']); d.point((24,49),fill=p['shade'])
 # Long hair / shorter hair silhouette. Body layers cover its middle.
 if rank=='Q':
  d.polygon([(19,30),(21,26),(28,26),(30,30),(31,44),(29,45),(27,41),(20,41),(18,45),(17,43)],fill=p['hair'])
 elif rank=='K':
  d.polygon([(19,30),(21,28),(28,28),(30,32),(29,39),(19,39),(18,36)],fill=p['hair'])
 else:
  d.polygon([(19,29),(22,27),(28,27),(30,31),(29,36),(18,36)],fill=p['hair'])
 # Neck and central head.
 d.rectangle((22,40,26,44),fill=p['skinshade'])
 d.rectangle((23,41,25,44),fill=p['skin'])
 d.polygon([(21,30),(27,30),(29,32),(29,38),(27,41),(21,41),(19,38),(19,33)],fill=p['skin'])
 d.rectangle((19,34,20,38),fill=p['skinshade'])
 d.line([(21,40),(27,40)], fill=p['skinshade'])
 d.point((20,35),fill=p['skin'])
 d.point((28,35),fill=p['skinshade'])
 # Portrait hair styling and facial details.
 if rank=='J':
  d.line([(20,31),(24,29),(28,31)],fill=p['hair'],width=2)
  d.rectangle((21,34,22,34),fill=dark)
  d.rectangle((26,34,27,34),fill=dark)
  d.point((24,37),fill=p['skinshade'])
  d.line([(23,39),(26,39)],fill=p['skinshade'])
  # asymmetrical cap with elegant trailing feather; per-suit variation.
  d.polygon([(17,28),(20,25),(29,25),(31,27),(31,30),(18,30)],fill=dark)
  d.polygon([(18,27),(20,26),(29,26),(30,28),(19,28)],fill=p['coat'])
  d.line([(19,29),(31,29)],fill=p['trim'],width=1)
  if suit in ('H','C'):
   d.polygon([(28,25),(31,21),(33,20),(32,25),(29,27)],fill=p['gem'])
  else:
   d.polygon([(20,25),(17,21),(15,22),(17,26),(20,27)],fill=p['gem'])
  d.point((25,27),fill=p['trim'])
 elif rank=='Q':
  d.line([(21,30),(22,28)],fill=p['hair'],width=2)
  d.line([(28,30),(27,28)],fill=p['hair'],width=2)
  d.point((22,34),fill=dark);d.point((26,34),fill=dark)
  d.point((24,37),fill=p['skinshade'])
  d.line([(22,39),(26,39)],fill=p['gem'])
  # gold tiara with 3 distinct peaks + colored gemstone.
  d.polygon([(19,29),(18,24),(21,26),(24,22),(27,26),(30,24),(29,29)],fill=dark)
  d.polygon([(20,28),(19,25),(22,27),(24,23),(26,27),(29,25),(28,28)],fill=p['trim'])
  d.rectangle((22,27,26,28),fill=p['trim'])
  d.point((24,26),fill=p['gem'])
  d.point((18,37),fill=p['trim']);d.point((30,37),fill=p['trim'])
 else:
  d.point((22,34),fill=dark);d.point((26,34),fill=dark)
  d.line([(21,33),(23,33)],fill=p['hair'])
  d.line([(25,33),(27,33)],fill=p['hair'])
  # moustache and large beard form the characteristic king's silhouette.
  d.polygon([(20,37),(23,38),(24,39),(25,38),(28,37),(29,39),(27,44),(24,46),(21,44),(19,39)], fill=p['hair'])
  d.point((24,38),fill=p['skin'])
  d.point((23,42),fill=p['shade']);d.point((26,42),fill=p['shade'])
  # four-point king crown
  d.polygon([(18,28),(17,22),(21,24),(24,20),(27,24),(31,22),(30,28)],fill=dark)
  d.polygon([(19,27),(18,23),(21,25),(24,21),(27,25),(30,23),(29,27)],fill=p['trim'])
  d.rectangle((19,27,29,29),fill=p['trim'])
  d.point((24,25),fill=p['gem'])
  d.point((20,25),fill=C['ivory_white']);d.point((28,25),fill=C['ivory_white'])
 # Cutout/filigree columns at base, consistent across all 12.
 d.point((13,22),fill=C['ivory_white']);d.point((34,22),fill=C['ivory_white'])
 d.point((13,52),fill=C['ivory_white']);d.point((34,52),fill=C['ivory_white'])
 # Four suit-specific insignia pixels in the frame, non-card-pip design.
 d.point((13,38),fill=p['gem']);d.point((34,38),fill=p['gem'])
 corner_indices(im,rank,suit)
 return im

def joker_card(which):
 im=card_template();d=ImageDraw.Draw(im)
 is_red=which=='red'
 p=ROYAL['H' if is_red else 'S'];c1=p['coat'];c2=p['trim'];c3=p['gem'];dk=C['outline']
 write_text(im,'JOKER',14,8,c1)
 # thin frame, theatrical circus arch.
 d.rectangle((10,19,37,58),fill=dk)
 d.rectangle((11,20,36,57),fill=c2)
 d.rectangle((12,21,35,56),fill=(250,230,199,255) if is_red else (225,228,243,255))
 d.polygon([(13,56),(16,48),(20,46),(28,46),(32,48),(35,56)],fill=dk)
 d.polygon([(14,55),(17,49),(21,47),(27,47),(31,49),(34,55)],fill=c1)
 d.polygon([(20,49),(24,53),(28,49),(26,55),(22,55)],fill=c2)
 for cx in [18,24,30]:
  d.point((cx,52),fill=C['ivory_white'])
 # original jester hat: two outwards curving horns plus center pin.
 d.polygon([(19,34),(15,31),(14,26),(12,26),(13,22),(16,25),(22,29),(23,34)],fill=dk)
 d.polygon([(20,33),(16,30),(15,25),(13,24),(16,24),(22,29)],fill=c1)
 d.polygon([(27,33),(29,27),(33,24),(35,26),(34,31),(31,34)],fill=dk)
 d.polygon([(27,32),(30,27),(33,25),(34,28),(31,31)],fill=(65,86,158,255) if is_red else (132,64,122,255))
 d.polygon([(21,32),(22,24),(24,21),(26,24),(27,32)],fill=dk)
 d.polygon([(22,31),(23,25),(24,23),(25,26),(26,31)],fill=c2)
 for x,y in [(13,22),(34,28),(24,21)]:
  d.rectangle((x-1,y-1,x+1,y+1),fill=dk)
  d.point((x,y),fill=C['gold_light'])
 # jester face
 d.polygon([(20,32),(27,32),(30,35),(29,43),(25,47),(22,47),(18,43),(18,36)],fill=dk)
 d.polygon([(20,33),(27,33),(29,36),(28,43),(25,46),(22,46),(19,42),(19,36)],fill=p['skin'])
 d.rectangle((21,37,22,38),fill=dk)
 d.rectangle((26,37,27,38),fill=dk)
 d.rectangle((23,40,25,40),fill=p['skinshade'])
 d.line([(21,42),(23,44),(26,44),(28,42)],fill=c1)
 d.rectangle((19,41,20,42),fill=p['skinshade'])
 d.rectangle((28,41,29,42),fill=p['skinshade'])
 # costume collar, 5 bright triangular spikes
 d.polygon([(18,46),(14,49),(19,50),(20,53),(24,50),(28,53),(29,50),(34,49),(29,46)],fill=dk)
 d.polygon([(18,47),(16,49),(20,49),(21,51),(24,49),(27,51),(28,49),(32,49),(29,47)],fill=c2)
 write_text(im,'RED' if is_red else 'BLACK', 18 if is_red else 14,61,c1)
 return im

def draw_back():
 im=Image.new('RGBA',(W,H),(0,0,0,0));d=ImageDraw.Draw(im)
 # exactly mirror-symmetrical base silhouette and trim
 d.polygon([(4,1),(43,1),(46,4),(46,67),(43,70),(4,70),(1,67),(1,4)],fill=C['outline'])
 d.polygon([(5,2),(42,2),(45,5),(45,66),(42,69),(5,69),(2,66),(2,5)],fill=C['gold_light'])
 d.polygon([(5,3),(42,3),(44,5),(44,66),(42,68),(5,68),(3,66),(3,5)],fill=C['burgundy_deep'])
 d.rectangle((5,6,42,65),fill=C['burgundy'])
 d.rectangle((7,8,40,63),outline=C['gold_light'])
 d.rectangle((9,10,38,61),outline=C['gold'])
 # mirrored four-quadrant details - ensures exact x/y symmetry
 def sym(x,y,color):
  for xx in {x,47-x}:
   for yy in {y,71-y}: d.point((xx,yy),fill=color)
 for x,y in [(11,13),(12,15),(13,17),(15,18),(11,26),(13,27),(15,29),
             (17,12),(19,14),(20,16),(17,20),(18,25),(19,30),
             (11,33),(15,34),(18,33)]: sym(x,y,C['gold_light'])
 for x,y in [(13,13),(14,14),(14,20),(16,22),(18,17),(21,21),(11,30),(13,32),(16,31)]: sym(x,y,C['ivory'])
 # central four-way rhombus, geometrically symmetrical
 d.polygon([(23,17),(24,17),(39,35),(39,36),(24,54),(23,54),(8,36),(8,35)],fill=C['gold_light'])
 d.polygon([(23,20),(24,20),(36,35),(36,36),(24,51),(23,51),(11,36),(11,35)],fill=C['burgundy_deep'])
 d.polygon([(23,25),(24,25),(32,35),(32,36),(24,46),(23,46),(15,36),(15,35)],outline=C['gold_light'])
 d.polygon([(23,28),(24,28),(29,35),(29,36),(24,43),(23,43),(18,36),(18,35)],fill=C['gold'])
 d.rectangle((22,34,25,37),fill=C['ivory'])
 # corners patterned identically: cross, dots
 for x,y in [(15,23),(21,18),(14,35),(18,49)]:
  sym(x,y,C['ivory'])
 # Strict fourfold symmetry: copy upper-left pixels through both axes.
 px=im.load()
 for y in range(36):
  for x in range(24):
   q=px[x,y]
   for xx in (x,47-x):
    for yy in (y,71-y): px[xx,yy]=q
 return im


def make_preview(ordered,files):
 # inspectable deck on a dark felt with labels; individual cards are not changed.
 scale=2; tilew,tileh=SW*scale,SH*scale
 gapx,gapy=20,38; left,top=52,146
 width=left*2+8*tilew+7*gapx
 height=top+7*tileh+6*gapy+80
 im=Image.new('RGB',(width,height),(22,34,43));d=ImageDraw.Draw(im)
 # geometric card-table frame
 d.rectangle((15,16,width-16,height-16),outline=(181,143,80),width=3)
 d.rectangle((22,23,width-23,height-23),outline=(65,87,84),width=2)
 font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',36)
 small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
 title='PIXEL PLAYING CARDS — COMPLETE 55-ASSET DECK'
 bbox=d.textbbox((0,0),title,font=font);d.text(((width-(bbox[2]-bbox[0]))//2,42),title,font=font,fill=(255,239,193))
 d.text((left,105),'52 standard cards  •  2 jokers  •  1 card back  |  96 × 144 px each',font=small,fill=(200,219,215))
 for idx,item in enumerate(ordered):
  r,c=divmod(idx,8);x=left+c*(tilew+gapx);y=top+r*(tileh+gapy)
  tile=files[item['id']].resize((tilew,tileh),Image.Resampling.NEAREST)
  im.paste(tile,(x,y),tile)
  label=item['id']
  bx=d.textbbox((0,0),label,font=small);d.text((x+(tilew-(bx[2]-bx[0]))//2,y+tileh+7),label,font=small,fill=(226,220,201))
 d.text((left,height-54),'Made with deterministic pip placement and original pixel portraits • transparent PNG exports',font=small,fill=(177,198,191))
 dest=ROOT/'preview'/'complete_deck_preview.png';dest.parent.mkdir(parents=True,exist_ok=True);im.save(dest,optimize=True)

def build():
 folders=['cards/hearts','cards/diamonds','cards/clubs','cards/spades','jokers','backs','spritesheets','preview',
          'assets_2x/cards/hearts','assets_2x/cards/diamonds','assets_2x/cards/clubs','assets_2x/cards/spades','assets_2x/jokers','assets_2x/backs']
 for f in folders: (ROOT/f).mkdir(parents=True,exist_ok=True)
 ordered=[];files={}
 for suit,letter,cname in SUITS:
  for rank in RANKS:
   cid=f'{rank}{letter}'
   logical = numeric_card(rank,letter) if rank in PIP_POINTS else face_card(rank,letter)
   img=logical.resize((SW,SH),Image.Resampling.NEAREST)
   relative=f'cards/{suit}/{cid}.png'
   img.save(ROOT/relative,optimize=True)
   img.resize(OUT2,Image.Resampling.NEAREST).save(ROOT/'assets_2x'/relative,optimize=True)
   ordered.append({'id':cid,'rank':rank,'suit':suit,'suit_symbol':{'H':'♥','D':'♦','C':'♣','S':'♠'}[letter],
                   'pip_count':len(PIP_POINTS[rank]) if rank in PIP_POINTS else None,
                   'path':relative,'path_2x':f'assets_2x/{relative}'})
   files[cid]=img
 for jid,kind in [('joker_red','red'),('joker_black','blue')]:
  relative=f'jokers/{jid}.png';img=joker_card('red' if kind=='red' else 'blue').resize((SW,SH),Image.Resampling.NEAREST)
  img.save(ROOT/relative,optimize=True);img.resize(OUT2,Image.Resampling.NEAREST).save(ROOT/'assets_2x'/relative,optimize=True)
  ordered.append({'id':jid,'type':'joker','variation':kind,'path':relative,'path_2x':f'assets_2x/{relative}'})
  files[jid]=img
 relative='backs/card_back.png';img=draw_back().resize((SW,SH),Image.Resampling.NEAREST)
 img.save(ROOT/relative,optimize=True);img.resize(OUT2,Image.Resampling.NEAREST).save(ROOT/'assets_2x'/relative,optimize=True)
 ordered.append({'id':'card_back','type':'back','path':relative,'path_2x':f'assets_2x/{relative}'})
 files['card_back']=img
 atlas=Image.new('RGBA',(8*SW,7*SH),C['transparent'])
 atlas2=Image.new('RGBA',(8*OUT2[0],7*OUT2[1]),C['transparent'])
 frames={}
 for idx,item in enumerate(ordered):
  r,c=divmod(idx,8);x,y=c*SW,r*SH
  atlas.paste(files[item['id']],(x,y))
  atlas2.paste(files[item['id']].resize(OUT2,Image.Resampling.NEAREST),(c*OUT2[0],r*OUT2[1]))
  item['atlas']={'x':x,'y':y,'w':SW,'h':SH,'index':idx}
  frames[item['id']]={'frame':{'x':x,'y':y,'w':SW,'h':SH},'rotated':False,'trimmed':False,
                      'spriteSourceSize':{'x':0,'y':0,'w':SW,'h':SH},'sourceSize':{'w':SW,'h':SH}}
 atlas.save(ROOT/'spritesheets/cards_atlas.png',optimize=True)
 atlas2.save(ROOT/'spritesheets/cards_atlas@2x.png',optimize=True)
 atlas_json={'frames':frames,'meta':{'app':'original-pixel-playing-cards','version':ARTIST_VERSION,
  'image':'cards_atlas.png','format':'RGBA8888','size':{'w':8*SW,'h':7*SH},'scale':'1',
  'grid':{'columns':8,'rows':7,'cell_width':SW,'cell_height':SH,'used':55,'empty':1},
  'order':'Hearts A-K, Diamonds A-K, Clubs A-K, Spades A-K, red joker, blue joker, card back'}}
 (ROOT/'spritesheets/cards_atlas.json').write_text(json.dumps(atlas_json,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
 manifest={'name':'Complete Pixel Art Playing Card Deck','version':ARTIST_VERSION,'authoring':'programmatic deterministic pixel art',
  'base_size':{'width':SW,'height':SH},'high_resolution_size':{'width':OUT2[0],'height':OUT2[1]},
  'assets_total':55,'standard_cards':52,'jokers':2,'backs':1,'assets':ordered}
 (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
 make_preview(ordered,files)
 (ROOT/'README.md').write_text('''# Complete Pixel Playing Card Deck (55 assets)\n\n**Includes:** 52 classic playing cards, 2 illustrated Jokers, and 1 symmetrical card back.\n\n- Standard cards: `cards/<suit>/<rank><letter>.png`\n- Jokers: `jokers/joker_red.png`, `jokers/joker_black.png`\n- Back: `backs/card_back.png`\n- HD versions: `assets_2x/` mirrored paths (192×288 pixels)\n- Atlas: `spritesheets/cards_atlas.png` (768×1008), and `cards_atlas@2x.png` (1536×2016)\n- Texturepacker-compatible metadata: `spritesheets/cards_atlas.json`\n- Detailed manifest: `manifest.json`\n- Contact sheet: `preview/complete_deck_preview.png`\n- Automated QA: `validation_report.json` and `validation_report.txt`\n\nAll images use RGBA and transparent pixels outside their pixel-stepped border.\nAtlas order: H A–K, D A–K, C A–K, S A–K, red Joker, blue Joker, card back. Last cell is blank.\n\nThis is original, programmatically painted pixel artwork. Symbols and ranks are deterministic rather than AI text rendering.\n\nRegenerate the original pack: `python generate_deck.py` (requires Pillow and NumPy). Run validation: `python validate_deck.py`.\n\nThe art is newly created for this pack without third-party artwork. You may integrate or adapt the output in your own game, subject to applicable terms and law.\n''',encoding='utf8')
 print(f'Generated {len(ordered)} assets in {ROOT}')

if __name__=='__main__': build()
