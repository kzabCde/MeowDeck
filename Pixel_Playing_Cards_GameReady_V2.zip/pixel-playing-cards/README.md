# Complete Pixel Playing Card Deck (55 assets)

**Includes:** 52 classic playing cards, 2 illustrated Jokers, and 1 symmetrical card back.

- Standard cards: `cards/<suit>/<rank><letter>.png`
- Jokers: `jokers/joker_red.png`, `jokers/joker_black.png`
- Back: `backs/card_back.png`
- HD versions: `assets_2x/` mirrored paths (192×288 pixels)
- Atlas: `spritesheets/cards_atlas.png` (768×1008), and `cards_atlas@2x.png` (1536×2016)
- Texturepacker-compatible metadata: `spritesheets/cards_atlas.json`
- Detailed manifest: `manifest.json`
- Contact sheet: `preview/complete_deck_preview.png`
- Automated QA: `validation_report.json` and `validation_report.txt`

All images use RGBA and transparent pixels outside their pixel-stepped border.
Atlas order: H A–K, D A–K, C A–K, S A–K, red Joker, blue Joker, card back. Last cell is blank.

This is original, programmatically painted pixel artwork. Symbols and ranks are deterministic rather than AI text rendering.

Regenerate the original pack: `python generate_deck.py` (requires Pillow and NumPy). Run validation: `python validate_deck.py`.

The art is newly created for this pack without third-party artwork. You may integrate or adapt the output in your own game, subject to applicable terms and law.
