#!/usr/bin/env python3
"""Independent pixel-based QA for generated playing cards. Execute after generation."""
from pathlib import Path
from PIL import Image
import json, numpy as np, sys
from collections import deque, Counter

ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf8'))
atlas_data=json.loads((ROOT/'spritesheets/cards_atlas.json').read_text(encoding='utf8'))
assets=manifest['assets']; frames=atlas_data['frames']; errors=[]; checks=[]

def check(name,cond,detail=None):
 checks.append({'check':name,'status':'PASS' if cond else 'FAIL','details':detail})
 if not cond: errors.append(name+(f': {detail}' if detail else ''))

def count_components(mask):
 # Four-neighbor region-growing, counted from the actual PNG pixel colors.
 mask=mask.astype(bool);h,w=mask.shape;visited=np.zeros_like(mask,dtype=bool); components=[]
 for y in range(h):
  for x in range(w):
   if not mask[y,x] or visited[y,x]:continue
   q=[(y,x)];visited[y,x]=True;n=0;coords=[]
   while q:
    cy,cx=q.pop();n+=1;coords.append((cy,cx))
    for ny,nx in [(cy-1,cx),(cy+1,cx),(cy,cx-1),(cy,cx+1)]:
     if 0<=ny<h and 0<=nx<w and mask[ny,nx] and not visited[ny,nx]:
      visited[ny,nx]=True;q.append((ny,nx))
   components.append((n,coords))
 return components

suit_sets={s:[] for s in ['hearts','diamonds','clubs','spades']}
seen_ids=[]; seen_paths=[]
check('Expected exactly 55 asset entries', len(assets)==55, len(assets))
check('Expected exactly 55 unique IDs', len(set(a['id'] for a in assets))==55)
check('Exactly 52 standard cards',sum('suit' in a for a in assets)==52)
check('Exactly 2 jokers',sum(a.get('type')=='joker' for a in assets)==2)
check('Exactly 1 back',sum(a.get('type')=='back' for a in assets)==1)

atlas=Image.open(ROOT/'spritesheets/cards_atlas.png').convert('RGBA')
atlas2=Image.open(ROOT/'spritesheets/cards_atlas@2x.png').convert('RGBA')
check('Atlas base dimensions',atlas.size==(768,1008),atlas.size)
check('Atlas 2x dimensions',atlas2.size==(1536,2016),atlas2.size)
check('Atlas JSON frame count',len(frames)==55,len(frames))
check('Atlas JSON grid specification',atlas_data['meta']['grid']=={'columns':8,'rows':7,'cell_width':96,'cell_height':144,'used':55,'empty':1})
check('Atlas extra grid cell completely transparent',not np.any(np.asarray(atlas.crop((7*96,6*144,8*96,7*144)))[:,:,3]))
check('Atlas 2x extra grid cell completely transparent',not np.any(np.asarray(atlas2.crop((7*192,6*288,8*192,7*288)))[:,:,3]))

# Test that the template itself produces a fully opaque face with alpha 0 off-card.
for i,a in enumerate(assets):
 p=ROOT/a['path'];p2=ROOT/a['path_2x'];cid=a['id']
 seen_ids.append(cid);seen_paths.append(a['path'])
 if 'suit' in a: suit_sets[a['suit']].append(a['rank'])
 exists=p.is_file() and p2.is_file()
 check(f'{cid}: both PNG exports exist',exists)
 if not exists:continue
 im=Image.open(p);im2=Image.open(p2)
 check(f'{cid}: base RGBA 96x144',im.mode=='RGBA' and im.size==(96,144),f'{im.mode} {im.size}')
 check(f'{cid}: high-res RGBA 192x288',im2.mode=='RGBA' and im2.size==(192,288),f'{im2.mode} {im2.size}')
 check(f'{cid}: exact 2x nearest-neighbor expansion',np.array_equal(np.asarray(im.resize((192,288),Image.Resampling.NEAREST)),np.asarray(im2)))
 arr=np.asarray(im)
 # pixel-stepped silhouette must be transparent in 4 corners and fully opaque inside.
 check(f'{cid}: transparent outer corners', all(arr[y,x,3]==0 for y,x in [(0,0),(0,95),(143,0),(143,95)]))
 check(f'{cid}: opaque card center',arr[72,48,3]==255)
 pos=frames.get(cid)
 check(f'{cid}: atlas metadata exists',pos is not None)
 if pos:
  rect=pos['frame'];expected={'x':(i%8)*96,'y':(i//8)*144,'w':96,'h':144}
  check(f'{cid}: atlas coordinates row-major correct',rect==expected,rect)
  crop=atlas.crop((rect['x'],rect['y'],rect['x']+96,rect['y']+144))
  check(f'{cid}: atlas pixel-perfect round trip',np.array_equal(np.asarray(im),np.asarray(crop)))
  crop2=atlas2.crop(((i%8)*192,(i//8)*288,(i%8+1)*192,(i//8+1)*288))
  check(f'{cid}: atlas2 pixel-perfect round trip',np.array_equal(np.asarray(im2),np.asarray(crop2)))
 if 'suit' in a:
  rank=a['rank'];suit=a['suit']
  if rank in ['A','2','3','4','5','6','7','8','9','10']:
   rgb=(165,34,53) if suit in ['hearts','diamonds'] else (35,34,49)
   # inspect only the central playing field, excluding corner indices and border
   region=arr[34:111,22:73:2,:3] if False else arr[34:112,22:74,:3]
   mask=np.all(region==np.array(rgb,dtype=np.uint8),axis=2)
   comps=count_components(mask)
   # Because card glyphs are 2x logical pixels, each pip should have >= 24 colored pixels.
   big=[c for c in comps if c[0]>=24]
   target=1 if rank=='A' else int(rank)
   check(f'{cid}: independent central pip connected-component count',len(big)==target,
         {'expected':target,'actual':len(big),'pixel_component_sizes':sorted((c[0] for c in comps),reverse=True)})
   # ensure no main pip is wrong-color (check region only; decorative border excluded).
   other_rgb=(35,34,49) if rgb==(165,34,53) else (165,34,53)
   check(f'{cid}: no wrong-color pips in central field',not np.any(np.all(region==np.array(other_rgb),axis=2)))
   # Verify actual bitmap silhouette for *every* main pip, independent of the count.
   # In particular, this detects red heart-vs-diamond or dark club-vs-spade swaps.
   from generate_deck import PIP_POINTS, BITMAP
   letter={'hearts':'H','diamonds':'D','clubs':'C','spades':'S'}[suit]
   pat=BITMAP[letter]
   unit_mask=np.array([[v=='X' for v in line] for line in pat],dtype=bool)
   logical=arr[::2,::2,:3]
   iconchecks=[]
   for cx,cy in PIP_POINTS[rank]:
    scale=2 if rank=='A' else 1
    x0=cx-(7*scale)//2;y0=cy-(7*scale)//2
    expected=np.repeat(np.repeat(unit_mask,scale,axis=0),scale,axis=1)
    observed=np.all(logical[y0:y0+7*scale,x0:x0+7*scale,:]==np.array(rgb,dtype=np.uint8),axis=2)
    iconchecks.append(np.array_equal(expected,observed))
   check(f'{cid}: exact expected suit shape at each center pip',all(iconchecks),f'{sum(iconchecks)}/{len(iconchecks)}')
 if cid=='card_back':
  check('Back horizontally mirror symmetric',np.array_equal(arr,arr[:,::-1]))
  check('Back vertically mirror symmetric',np.array_equal(arr,arr[::-1,:]))

for suit,ranks in suit_sets.items():
 check(f'{suit}: exactly A,2..10,J,Q,K once each', sorted(ranks)==sorted(['A','2','3','4','5','6','7','8','9','10','J','Q','K']),ranks)
check('All image relative paths unique',len(set(seen_paths))==55)
check('12 face-card PNGs all visually distinct',len({(ROOT/a['path']).read_bytes() for a in assets if a.get('rank') in ['J','Q','K']})==12)
check('Two joker PNGs visually distinct',(ROOT/'jokers/joker_red.png').read_bytes()!=(ROOT/'jokers/joker_black.png').read_bytes())
check('File preview exists',(ROOT/'preview/complete_deck_preview.png').is_file())
check('All source and package docs exist',(ROOT/'generate_deck.py').is_file() and (ROOT/'README.md').is_file())
report={'status':'PASS' if not errors else 'FAIL','total_checks':len(checks),'passed':len(checks)-len(errors),'failed':len(errors),
        'assets_verified':len(assets),'pips_verified_on_numeric_cards':40,'checks':checks,'errors':errors}
(ROOT/'validation_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
(RootReport:=ROOT/'validation_report.txt').write_text(
 f"PIXEL PLAYING CARD DECK — VALIDATION REPORT\nSTATUS: {report['status']}\nCHECKS PASSED: {report['passed']} / {report['total_checks']}\nFAILED: {report['failed']}\nCARDS: 52 + 2 jokers + 1 back = 55\n\n"+ '\n'.join(('PASS' if c['status']=='PASS' else 'FAIL')+' '+c['check']+' '+(str(c['details']) if c['details'] is not None else '') for c in checks)+'\n',encoding='utf8')
print(report['status'],report['passed'],'/',report['total_checks'])
for err in errors[:60]: print('FAIL',err)
if errors:sys.exit(1)
