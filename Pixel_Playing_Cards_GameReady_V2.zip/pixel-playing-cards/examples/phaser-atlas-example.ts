/** Example Phaser 3/Next.js integration. Serve the spritesheets folder as public assets. */
import Phaser from 'phaser';

export class CardScene extends Phaser.Scene {
  constructor() { super('CardScene'); }

  preload() {
    this.load.atlas(
      'playing-cards',
      '/playing-cards/cards_atlas.png',
      '/playing-cards/cards_atlas.json',
    );
  }

  create() {
    const ace = this.add.image(120, 130, 'playing-cards', 'AH');
    ace.setScale(2); // Pixel-perfect integer scaling: 96×144 -> 192×288

    const back = this.add.image(280, 130, 'playing-cards', 'card_back');
    back.setScale(1);
    this.cameras.main.roundPixels = true;
  }
}
