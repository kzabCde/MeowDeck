# PIXEL DECK — MOCHI Animation Pack

Includes 10 Mochi animations, 44 sequential frames total.

## Sheet format
- Pixel format: transparent RGBA PNG
- Frame dimensions: 96 × 96 px
- Sheet layout: horizontal, left-to-right, one row each
- Global anchor: (48, 88) pixels, origin in engine normalized coordinates: (0.5, 0.9166667)
- No cards, table, text, labels, or effects are included in sprite sheets.
- Nearest-neighbor scaling required in-game (`pixelArt: true`).

## Animations
- `idle`: 4 frames, 5 fps, loop — `sprites/mochi_idle_4f_96x96.png`
- `blink`: 3 frames, 8 fps, one-shot — `sprites/mochi_blink_3f_96x96.png`
- `thinking`: 4 frames, 6 fps, one-shot — `sprites/mochi_thinking_4f_96x96.png`
- `draw_card`: 6 frames, 9 fps, one-shot — `sprites/mochi_draw_card_6f_96x96.png`
- `play_card`: 6 frames, 9 fps, one-shot — `sprites/mochi_play_card_6f_96x96.png`
- `victory`: 6 frames, 9 fps, one-shot — `sprites/mochi_victory_6f_96x96.png`
- `defeat`: 4 frames, 6 fps, one-shot — `sprites/mochi_defeat_4f_96x96.png`
- `sleep`: 4 frames, 4 fps, loop — `sprites/mochi_sleep_4f_96x96.png`
- `pet_reaction`: 4 frames, 6 fps, one-shot — `sprites/mochi_pet_reaction_4f_96x96.png`
- `surprise`: 3 frames, 10 fps, one-shot — `sprites/mochi_surprise_3f_96x96.png`

## Phaser 3 setup example
```ts
this.load.spritesheet('mochi_idle', '/sprites/mochi_idle_4f_96x96.png', { frameWidth: 96, frameHeight: 96 });
this.anims.create({ key: 'mochi-idle', frames: this.anims.generateFrameNumbers('mochi_idle', { start: 0, end: 3 }), frameRate: 5, repeat: -1 });
const cat = this.add.sprite(400, 300, 'mochi_idle').setOrigin(0.5, 88 / 96);
cat.play('mochi-idle');
```
Frame-dependent card graphics and movement are the game engine's responsibility.

Previews are for inspection and have a neutral background. PNG sheets themselves are fully transparent.
